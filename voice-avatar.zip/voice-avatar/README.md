# Saathi — 3D बोलने वाला Voice Avatar (Next.js)

एक 3D animated character जो **type नहीं करता, सीधा बोलता है** — आप माइक से बोलिए,
character आपकी बात सुनता है, "सोचता" है, और फिर अपनी असली आवाज़ में जवाब देता है
(Text-to-Speech), साथ में उसका मुँह बोलते हुए हिलता भी है (lip-sync जैसा effect).

**कोई database नहीं है** — सब कुछ browser में chalta hai, server सिर्फ एक stateless
API route है जो jawab generate karta hai.

## कैसे काम करता है

- **3D character**: `react-three-fiber` + `three.js` से बना एक organic blob
  character, जिसकी shape/glow बोलते समय real-time पर बदलती है.
- **सुनना (STT)**: Browser का built-in `SpeechRecognition` API (Chrome/Edge में
  सबसे अच्छा काम करता है).
- **बोलना (TTS)**: Browser का built-in `SpeechSynthesis` API — हर शब्द के
  boundary event पर character का मुँह हिलता है, इसलिए आवाज़ के साथ sync रहता है.
- **जवाब generate करना**: `/api/chat` route — अगर आप `ANTHROPIC_API_KEY` देंगे
  तो असली AI जवाब देगा, वरना एक छोटा सा local fallback जवाब देगा (demo के लिए).

## Setup

```bash
npm install
```

(Optional, असली AI जवाब के लिए) `.env.local.example` को copy करके `.env.local`
बनाएं और अपनी key डालें:

```bash
cp .env.local.example .env.local
# ANTHROPIC_API_KEY=sk-ant-...
```

## चलाना

```bash
npm run dev
```

फिर [http://localhost:3000](http://localhost:3000) खोलें, माइक की permission
allow करें, और mic button दबाकर बोलना शुरू करें.

> ध्यान दें: `SpeechRecognition` API सबसे अच्छा **Chrome या Edge** में काम करता
> है. Production में deploy करते समय HTTPS ज़रूरी है (Vercel पर deploy करने से
> यह अपने आप मिल जाता है).

## Deploy

यह standard Next.js app है — [Vercel](https://vercel.com) पर सीधे deploy हो
जाएगा. Vercel dashboard में `ANTHROPIC_API_KEY` environment variable set करना
न भूलें अगर असली AI जवाब चाहिए.

## Structure

```
app/
  page.tsx              → main screen
  api/chat/route.ts     → jawab generate karta hai (Anthropic API ya fallback)
components/
  VoiceOrb.tsx           → 3D talking character
  VoiceAssistant.tsx     → mic + state machine + captions
hooks/
  useSpeechRecognition.ts → mic input + live volume level
  useSpeechSynthesis.ts   → voice output + mouth-level envelope
```

## Customize

- **भाषा बदलें**: `hooks/useSpeechRecognition.ts` और
  `components/VoiceAssistant.tsx` में `lang: 'hi-IN'` को `'en-US'` या किसी और
  locale से बदलें.
- **Character का रंग/शक्ल**: `components/VoiceOrb.tsx` में `STATE_COLOR` और
  geometry values बदलें.
- **Personality**: `app/api/chat/route.ts` में `SYSTEM_PROMPT` edit करें.
