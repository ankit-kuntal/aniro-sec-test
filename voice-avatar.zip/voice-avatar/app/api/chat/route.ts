import { NextRequest, NextResponse } from 'next/server';

// No database — each request carries its own short rolling history from
// the browser (kept in React state), so the server stays stateless.

const SYSTEM_PROMPT = `Tum ek dost jaisa bolne wala voice assistant ho, jiska naam "Saathi" hai.
Tumhara jawab seedha bola (TTS) jayega, isliye:
- Chhoti, natural, bolchaal wali Hinglish/Hindi mein jawab do (jaisa insaan bolta hai).
- 1-3 vaakya se zyada mat likho, jab tak user detail na maange.
- Koi markdown, bullet points, asterisks, ya emoji mat likho — sirf plain bola jaane wala text.
- Warm aur seedha tone rakho.`;

type ChatMessage = { role: 'user' | 'assistant'; content: string };

function fallbackReply(message: string): string {
  const lower = message.toLowerCase();
  if (/(namaste|hello|hi|hey)/.test(lower)) {
    return 'Namaste! Main Saathi hoon. Aaj main aapki kaise madad kar sakta hoon?';
  }
  if (/(naam|tum kaun)/.test(lower)) {
    return 'Mera naam Saathi hai, aur main ek awaaz wala AI hoon jo type nahi karta, seedha baat karta hai.';
  }
  return `Aapne kaha: "${message}". Abhi mujhe ek asli AI jawab dene ke liye ANTHROPIC_API_KEY set nahi mila hai, isliye main sirf echo kar raha hoon — README mein setup dekhein.`;
}

export async function POST(req: NextRequest) {
  try {
    const { message, history } = (await req.json()) as {
      message: string;
      history?: ChatMessage[];
    };

    if (!message || typeof message !== 'string') {
      return NextResponse.json({ error: 'message required' }, { status: 400 });
    }

    const apiKey = process.env.ANTHROPIC_API_KEY;

    if (!apiKey) {
      return NextResponse.json({ reply: fallbackReply(message) });
    }

    const messages: ChatMessage[] = [...(history ?? []).slice(-10), { role: 'user', content: message }];

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: process.env.ANTHROPIC_MODEL || 'claude-sonnet-5',
        max_tokens: 300,
        system: SYSTEM_PROMPT,
        messages,
      }),
    });

    if (!response.ok) {
      const errText = await response.text();
      console.error('Anthropic API error:', errText);
      return NextResponse.json({ reply: fallbackReply(message) });
    }

    const data = await response.json();
    const reply = data.content
      ?.filter((block: any) => block.type === 'text')
      .map((block: any) => block.text)
      .join(' ')
      .trim();

    return NextResponse.json({ reply: reply || fallbackReply(message) });
  } catch (err) {
    console.error('chat route error:', err);
    return NextResponse.json({ reply: 'Kuch gadbad ho gayi, dobara koshish karein.' }, { status: 200 });
  }
}
