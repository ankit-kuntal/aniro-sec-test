import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Saathi — बोलने वाला AI साथी',
  description: 'एक 3D वॉइस अवतार जो टाइप नहीं करता, बोलता है।',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="hi">
      <body>{children}</body>
    </html>
  );
}
