'use client';

import dynamic from 'next/dynamic';

const VoiceAssistant = dynamic(() => import('@/components/VoiceAssistant'), {
  ssr: false,
});

export default function Home() {
  return <VoiceAssistant />;
}
