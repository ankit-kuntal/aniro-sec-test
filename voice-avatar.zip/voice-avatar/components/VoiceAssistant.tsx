'use client';

import { useCallback, useRef, useState } from 'react';
import VoiceOrb, { AssistantState } from './VoiceOrb';
import { useSpeechRecognition } from '@/hooks/useSpeechRecognition';
import { useSpeechSynthesis } from '@/hooks/useSpeechSynthesis';

type Turn = { role: 'user' | 'assistant'; content: string };

const STATE_LABEL: Record<AssistantState, string> = {
  idle: 'TAP TO SPEAK',
  listening: 'SUN RAHA HOON…',
  thinking: 'SOCH RAHA HOON…',
  speaking: 'BOL RAHA HOON…',
};

export default function VoiceAssistant() {
  const [state, setState] = useState<AssistantState>('idle');
  const [level, setLevel] = useState(0);
  const [caption, setCaption] = useState('');
  const [showCaptions, setShowCaptions] = useState(true);
  const historyRef = useRef<Turn[]>([]);

  const { speak } = useSpeechSynthesis();

  const handleFinalTranscript = useCallback(
    async (transcript: string) => {
      setCaption(transcript);
      setState('thinking');
      historyRef.current.push({ role: 'user', content: transcript });

      let reply = '';
      try {
        const res = await fetch('/api/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ message: transcript, history: historyRef.current }),
        });
        const data = await res.json();
        reply = data.reply || 'Maaf kijiye, main samajh nahi paya.';
      } catch {
        reply = 'Network mein dikkat aa rahi hai, dobara koshish karein.';
      }

      historyRef.current.push({ role: 'assistant', content: reply });
      setCaption(reply);
      setState('speaking');
      speak(reply, {
        onLevel: (l) => setLevel(l),
        onEnd: () => setState('idle'),
      });
    },
    [speak]
  );

  const recognition = useSpeechRecognition({
    onLevel: (l) => setLevel(l),
    onResult: handleFinalTranscript,
  });

  const handleMicTap = () => {
    if (state === 'listening') {
      recognition.stop();
      setState('idle');
      return;
    }
    if (state !== 'idle') return; // ignore taps while thinking/speaking
    setCaption('');
    setState('listening');
    recognition.start();
  };

  const unsupported = !recognition.supported;

  return (
    <main
      style={{
        height: '100dvh',
        width: '100%',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '28px 20px 40px',
      }}
    >
      <header
        style={{
          width: '100%',
          maxWidth: 560,
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
        }}
      >
        <span className="display" style={{ fontSize: 18, letterSpacing: 1, color: 'var(--paper)' }}>
          Saathi
        </span>
        <button
          onClick={() => setShowCaptions((s) => !s)}
          className="mono"
          style={{
            background: 'transparent',
            border: '1px solid rgba(234,242,242,0.18)',
            color: 'var(--mist)',
            borderRadius: 999,
            padding: '6px 14px',
            fontSize: 11,
            letterSpacing: 0.6,
            cursor: 'pointer',
          }}
        >
          {showCaptions ? 'CAPTIONS: ON' : 'CAPTIONS: OFF'}
        </button>
      </header>

      <div style={{ flex: 1, width: '100%', maxWidth: 620 }}>
        <VoiceOrb state={state} level={level} />
      </div>

      <section style={{ width: '100%', maxWidth: 560, textAlign: 'center' }}>
        {showCaptions && caption && (
          <p
            className="mono"
            style={{
              color: 'var(--mist)',
              fontSize: 13,
              lineHeight: 1.6,
              minHeight: 40,
              marginBottom: 18,
              padding: '0 12px',
            }}
          >
            {caption}
          </p>
        )}

        <p
          className="mono"
          style={{
            color: 'var(--mist)',
            fontSize: 11,
            letterSpacing: 2,
            marginBottom: 18,
          }}
        >
          {unsupported ? 'IS BROWSER MEIN VOICE INPUT SUPPORTED NAHI HAI' : STATE_LABEL[state]}
        </p>

        <button
          onClick={handleMicTap}
          disabled={unsupported || state === 'thinking' || state === 'speaking'}
          aria-label="Mic"
          style={{
            width: 74,
            height: 74,
            borderRadius: '50%',
            border: '2px solid var(--aqua-400)',
            background:
              state === 'listening' ? 'var(--ember-400)' : 'rgba(94, 234, 212, 0.08)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            cursor: unsupported ? 'not-allowed' : 'pointer',
            opacity: state === 'thinking' || state === 'speaking' ? 0.4 : 1,
            transition: 'background 0.2s ease, opacity 0.2s ease',
          }}
        >
          <svg width="26" height="26" viewBox="0 0 24 24" fill="none">
            <rect x="9" y="2" width="6" height="12" rx="3" fill="var(--paper)" />
            <path
              d="M5 11a7 7 0 0 0 14 0M12 18v3"
              stroke="var(--paper)"
              strokeWidth="1.8"
              strokeLinecap="round"
            />
          </svg>
        </button>
      </section>
    </main>
  );
}
