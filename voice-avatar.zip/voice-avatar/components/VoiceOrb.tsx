'use client';

import { useMemo, useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { MeshDistortMaterial, Sphere } from '@react-three/drei';
import * as THREE from 'three';

export type AssistantState = 'idle' | 'listening' | 'thinking' | 'speaking';

const STATE_COLOR: Record<AssistantState, string> = {
  idle: '#5eead4',
  listening: '#ffb454',
  thinking: '#a78bfa',
  speaking: '#5eead4',
};

function Organism({ state, level }: { state: AssistantState; level: number }) {
  const group = useRef<THREE.Group>(null);
  const material = useRef<any>(null);
  const mouth = useRef<THREE.Mesh>(null);
  const eyeL = useRef<THREE.Mesh>(null);
  const eyeR = useRef<THREE.Mesh>(null);

  const color = useMemo(() => new THREE.Color(STATE_COLOR[state]), [state]);
  const smoothed = useRef(0);
  const blink = useRef(0);
  const nextBlink = useRef(2 + Math.random() * 3);

  useFrame((_, delta) => {
    // ease the incoming level so the blob breathes rather than jitters
    smoothed.current += (level - smoothed.current) * Math.min(1, delta * 10);
    const lvl = smoothed.current;

    if (group.current) {
      const idleBob = Math.sin(performance.now() / 900) * 0.04;
      const scale = 1 + lvl * 0.18;
      group.current.scale.setScalar(scale);
      group.current.position.y = idleBob + (state === 'listening' ? 0.02 : 0);
      // gentle sway rather than a full spin, so the face keeps reading
      const swayAmount = state === 'thinking' ? 0.18 : 0.05;
      group.current.rotation.y = Math.sin(performance.now() / 1400) * swayAmount;
    }

    if (material.current) {
      material.current.distort = 0.25 + lvl * 0.35 + (state === 'thinking' ? 0.15 : 0);
      material.current.speed = state === 'thinking' ? 3.5 : 1.2 + lvl * 3;
      material.current.color.lerp(color, delta * 4);
      material.current.emissive?.lerp?.(color, delta * 4);
    }

    if (mouth.current) {
      const openness = 0.05 + lvl * 0.55;
      mouth.current.scale.y = openness;
      (mouth.current.material as THREE.MeshStandardMaterial).opacity = 0.85;
    }

    // simple periodic blink, independent of talking state
    blink.current += delta;
    if (blink.current > nextBlink.current) {
      blink.current = 0;
      nextBlink.current = 2.5 + Math.random() * 3;
    }
    const blinkPhase = blink.current < 0.12 ? Math.abs(Math.sin((blink.current / 0.12) * Math.PI)) : 0;
    const eyeScale = 1 - blinkPhase * 0.9;
    if (eyeL.current) eyeL.current.scale.y = eyeScale;
    if (eyeR.current) eyeR.current.scale.y = eyeScale;
  });

  return (
    <group ref={group}>
      <Sphere args={[1.3, 128, 128]}>
        <MeshDistortMaterial
          ref={material}
          color={STATE_COLOR[state]}
          roughness={0.15}
          metalness={0.1}
          distort={0.3}
          speed={1.5}
          transparent
          opacity={0.95}
        />
      </Sphere>

      {/* face plate, slightly in front of the blob surface */}
      <mesh ref={eyeL} position={[-0.42, 0.28, 1.12]}>
        <sphereGeometry args={[0.09, 16, 16]} />
        <meshStandardMaterial color="#0b0f14" />
      </mesh>
      <mesh ref={eyeR} position={[0.42, 0.28, 1.12]}>
        <sphereGeometry args={[0.09, 16, 16]} />
        <meshStandardMaterial color="#0b0f14" />
      </mesh>
      <mesh ref={mouth} position={[0, -0.28, 1.18]}>
        <capsuleGeometry args={[0.05, 0.42, 4, 8]} />
        <meshStandardMaterial color="#0b0f14" transparent opacity={0.85} />
      </mesh>
    </group>
  );
}

export default function VoiceOrb({ state, level }: { state: AssistantState; level: number }) {
  return (
    <Canvas camera={{ position: [0, 0, 4.2], fov: 45 }} dpr={[1, 2]}>
      <ambientLight intensity={0.5} />
      <pointLight position={[3, 3, 4]} intensity={1.4} color={STATE_COLOR[state]} />
      <pointLight position={[-3, -2, 3]} intensity={0.5} color="#ffffff" />
      <Organism state={state} level={level} />
    </Canvas>
  );
}
