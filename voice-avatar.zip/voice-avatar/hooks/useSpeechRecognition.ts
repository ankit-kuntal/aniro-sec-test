'use client';

import { useCallback, useEffect, useRef, useState } from 'react';

type Options = {
  lang?: string;
  onLevel?: (level: number) => void;
  onResult?: (transcript: string) => void;
};

export function useSpeechRecognition(opts: Options = {}) {
  const { lang = 'hi-IN', onLevel, onResult } = opts;
  const [supported, setSupported] = useState(false);
  const [listening, setListening] = useState(false);
  const [interim, setInterim] = useState('');

  const recognitionRef = useRef<any>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const rafRef = useRef<number>();

  useEffect(() => {
    if (typeof window === 'undefined') return;
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    setSupported(!!SR);
  }, []);

  const stopMeter = useCallback(() => {
    if (rafRef.current) cancelAnimationFrame(rafRef.current);
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    audioCtxRef.current?.close().catch(() => {});
    audioCtxRef.current = null;
  }, []);

  const startMeter = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
      audioCtxRef.current = ctx;
      const source = ctx.createMediaStreamSource(stream);
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 256;
      source.connect(analyser);
      const data = new Uint8Array(analyser.frequencyBinCount);

      const tick = () => {
        analyser.getByteFrequencyData(data);
        const avg = data.reduce((a, b) => a + b, 0) / data.length;
        onLevel?.(Math.min(1, avg / 90));
        rafRef.current = requestAnimationFrame(tick);
      };
      tick();
    } catch {
      // mic permission denied — recognition may still work without the meter
    }
  }, [onLevel]);

  const stop = useCallback(() => {
    recognitionRef.current?.stop();
    stopMeter();
    onLevel?.(0);
    setListening(false);
  }, [onLevel, stopMeter]);

  const start = useCallback(() => {
    if (typeof window === 'undefined') return;
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SR) return;

    const recognition = new SR();
    recognition.lang = lang;
    recognition.continuous = false;
    recognition.interimResults = true;

    recognition.onstart = () => {
      setListening(true);
      startMeter();
    };

    recognition.onresult = (event: any) => {
      let finalText = '';
      let interimText = '';
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const chunk = event.results[i][0].transcript;
        if (event.results[i].isFinal) finalText += chunk;
        else interimText += chunk;
      }
      setInterim(interimText);
      if (finalText.trim()) {
        onResult?.(finalText.trim());
      }
    };

    recognition.onerror = () => {
      stopMeter();
      setListening(false);
    };

    recognition.onend = () => {
      stopMeter();
      onLevel?.(0);
      setListening(false);
      setInterim('');
    };

    recognitionRef.current = recognition;
    recognition.start();
  }, [lang, onLevel, onResult, startMeter, stopMeter]);

  useEffect(() => stop, [stop]);

  return { supported, listening, interim, start, stop };
}
