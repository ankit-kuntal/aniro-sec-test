'use client';

import { useCallback, useEffect, useRef, useState } from 'react';

type SpeakOptions = {
  onLevel?: (level: number) => void;
  onEnd?: () => void;
  lang?: string;
};

/**
 * Wraps window.speechSynthesis. The Web Speech API does not expose the
 * raw audio stream of a TTS utterance, so there is no waveform to analyse
 * directly. Instead we approximate a mouth-open envelope: each `onboundary`
 * event (fired per word) pulses the level up, and a small animation loop
 * decays it back down between words — giving a believable talking rhythm
 * synced to the actual words being spoken.
 */
export function useSpeechSynthesis() {
  const [supported, setSupported] = useState(false);
  const [speaking, setSpeaking] = useState(false);
  const levelRef = useRef(0);
  const rafRef = useRef<number>();
  const voicesRef = useRef<SpeechSynthesisVoice[]>([]);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    if (!('speechSynthesis' in window)) return;
    setSupported(true);

    const loadVoices = () => {
      voicesRef.current = window.speechSynthesis.getVoices();
    };
    loadVoices();
    window.speechSynthesis.onvoiceschanged = loadVoices;
  }, []);

  const pickVoice = useCallback((lang: string) => {
    const voices = voicesRef.current;
    return (
      voices.find((v) => v.lang.toLowerCase() === lang.toLowerCase()) ||
      voices.find((v) => v.lang.toLowerCase().startsWith(lang.slice(0, 2).toLowerCase())) ||
      voices.find((v) => v.default) ||
      voices[0]
    );
  }, []);

  const stop = useCallback(() => {
    if (typeof window === 'undefined') return;
    window.speechSynthesis.cancel();
    if (rafRef.current) cancelAnimationFrame(rafRef.current);
    levelRef.current = 0;
    setSpeaking(false);
  }, []);

  const speak = useCallback(
    (text: string, opts: SpeakOptions = {}) => {
      if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
      const { onLevel, onEnd, lang = 'hi-IN' } = opts;

      window.speechSynthesis.cancel();

      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = lang;
      utterance.rate = 1;
      utterance.pitch = 1;
      const voice = pickVoice(lang);
      if (voice) utterance.voice = voice;

      let lastPulse = 0;

      utterance.onboundary = () => {
        levelRef.current = 1;
        lastPulse = performance.now();
      };

      utterance.onstart = () => {
        setSpeaking(true);
        const tick = () => {
          const dt = performance.now() - lastPulse;
          // decay the pulse over ~220ms so consecutive words blend into
          // a continuous talking motion instead of a strobe
          const decayed = Math.max(0, 1 - dt / 220);
          levelRef.current = decayed;
          onLevel?.(levelRef.current);
          rafRef.current = requestAnimationFrame(tick);
        };
        tick();
      };

      utterance.onend = () => {
        if (rafRef.current) cancelAnimationFrame(rafRef.current);
        levelRef.current = 0;
        onLevel?.(0);
        setSpeaking(false);
        onEnd?.();
      };

      utterance.onerror = () => {
        if (rafRef.current) cancelAnimationFrame(rafRef.current);
        levelRef.current = 0;
        onLevel?.(0);
        setSpeaking(false);
        onEnd?.();
      };

      window.speechSynthesis.speak(utterance);
    },
    [pickVoice]
  );

  useEffect(() => stop, [stop]);

  return { supported, speaking, speak, stop };
}
